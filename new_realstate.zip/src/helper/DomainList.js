// import realestatedomain from '../assets/realestatedomain.jpg';
// import digitaldomain from '../assets/digitaldomain.jpg';
// import ecommercedomain from '../assets/ecommercedomain.jpg';
// import mobileappdomain from '../assets/mobileappdomain.jpg';
// import govtdomain from '../assets/govtdomain.jpg';
// import healthcaredomain from '../assets/healthcaredomain.jpg';

// export const DomainList = [
//     {
//         name : "Real e-State",
//         image : realestatedomain,
//     },
//     {
//         name : "Digital Marketing Service",
//         image : digitaldomain,
//     },
//     {
//         name : "E commerce Industry",
//         image : ecommercedomain,
//     },
//     {
//         name : "Mobile Apps Development",
//         image : mobileappdomain,
//     },
//     {
//         name : "Government Industry",
//         image : govtdomain,
//     },
//     {
//         name : "Healthcare Industry",
//         image : healthcaredomain,
//     },
// ]
